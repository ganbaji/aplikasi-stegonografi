<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StegoController extends Controller
{
    private function index()
    {
        // dd($this->ambildata());
        return view('generateKey');
    
    }



    public function calculate(Request $request)
    {
        $request->validate([
            'p' => 'required|integer',
            'q' => 'required|integer',
        ]);

        $p = $request->input('p');
        $q = $request->input('q');

    
        if ($this->isPrime($p) && $this->isPrime($q)) {
            $n = $p * $q;                    // hitung nilai n
            $phi_n = ($p-1) * ($q-1);       //hitung nilai m


        // Pilih e yang relatif prima dengan φ(n)
        $e = $this->findE($phi_n);
        if ($e === -1) {
            return response()->json(['error' => 'Failed to find appropriate e'], 400);
        }

        // Hitung d (invers modular e modulo φ(n))
        $d = $this->modInverse($e, $phi_n);

        // Output kunci publik dan privat
        $publicKey = ['e' => $e, 'n' => $n];
        $privateKey = ['d' => $d, 'n' => $n];


        // return response()->json([
        //     'public_key' => $publicKey,
        //     'private_key' => $privateKey,
        //     // 'nilai N' => $n,
        //     // 'nilai Phi N' => $phi_n,
        //     // 'nilai E' => $e,
        //     // 'nilai D' => $d,
            
        // ]);

            session([
                'nilaiN' =>$n,
                'nilaiM' =>$phi_n,
                'nilaiE' =>$e,
                'nilaiD' =>$d,
                'publicKey' =>$publicKey,
                'privateKey' =>$privateKey
            ]);

            return view('generateKey', compact('p', 'q', 'phi_n', 'n', 'e', 'd', 'privateKey', 'publicKey'));
        } else {
            return redirect()->back()->with(['error' => 'Both numbers must be prime.']);
        }
    }

    private function isPrime($number)
    {
        if ($number < 2) {
            return false;
        }
        for ($i = 2; $i <= sqrt($number); $i++) {
            if ($number % $i == 0) {
                return false;
            }
        }
        return true;
    }

    private function gcd($a, $b)
    {
        while ($b != 0) {
            $t = $b;
            $b = $a % $b;
            $a = $t;
        }
        return $a;
    }
    
    private function findE($phi)
    {
        for ($e = 2; $e < $phi; $e++) {
            if ($this->gcd($e, $phi) == 1) {
                return $e;
            }
        }
        return -1;  // Jika tidak ada e yang ditemukan
    }


    private function modInverse($a, $m)
    {
        $m0 = $m;
        $y = 0;
        $x = 1;

        if ($m == 1) {
            return 0;
        }

        while ($a > 1) {
            // q is quotient
            $q = intval($a / $m);
            $t = $m;

            // m is remainder now, process same as Euclid's algo
            $m = $a % $m;
            $a = $t;
            $t = $y;

            // Update x and y
            $y = $x - $q * $y;
            $x = $t;
        }

        // Make x positive
        if ($x < 0) {
            $x += $m0;
        }

        return $x;
    }






        // public function ambildata () {

        //     $pnew = session('result');
        //     return $pnew;
            
            
        // }
        public function showHideForm()
        {
            return view('hide');
        }
 
        public function hideFile(Request $request)
        {
            $request->validate([
                'image' => 'required|image|mimes:png',
                'file' => 'required|file|mimes:xlsx,xls'
            ]);
    
            $imagePath = $request->file('image')->getPathName();
            $filePath = $request->file('file')->getPathName();
    
            $outputImagePath = storage_path('app/public/output.png');
            dd($imagePath, $filePath, $outputImagePath);
            
            $this->hideFileInImage($imagePath, $filePath, $outputImagePath);
    
            return response()->download($outputImagePath);
        }
    
        public function showExtractForm()
        {
            return view('extract');
        }
    
        public function extractFile(Request $request)
        {
            $request->validate([
                'image' => 'required|image|mimes:png'
            ]);
    
            $imagePath = $request->file('image')->getPathName();
            $outputFilePath = storage_path('app/public/extracted_file.xlsx');
    
            $this->readFileFromImage($imagePath, $outputFilePath);
    
            return response()->download($outputFilePath);
        }
    
        private function hideFileInImage($imagePath, $filePath, $outputImagePath)
        {
            $image = imagecreatefrompng($imagePath);
            if (!$image) {
                die("Gagal membuka gambar.");
            }
    
            $fileContents = file_get_contents($filePath);
            $fileSize = strlen($fileContents);
    
            // Mengonversi panjang file menjadi bit-bit
            $sizeBits = str_pad(decbin($fileSize), 32, '0', STR_PAD_LEFT);
    
            // Menggabungkan bit panjang file dan bit file asli
            $fileBits = $sizeBits;
            for ($i = 0; $i < $fileSize; $i++) {
                $char = $fileContents[$i];
                $fileBits .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
            }
    
            $width = imagesx($image);
            $height = imagesy($image);
            $totalPixels = $width * $height;
    
            if (strlen($fileBits) > $totalPixels * 3) { // Karena kita menggunakan R, G, dan B
                die("File terlalu besar untuk disembunyikan dalam gambar ini.");
            }
    
            $bitIndex = 0;
            for ($y = 0; $y < $height; $y++) {
                for ($x = 0; $x < $width; $x++) {
                    if ($bitIndex >= strlen($fileBits)) {
                        break 2;
                    }
    
                    $rgb = imagecolorat($image, $x, $y);
                    $colors = imagecolorsforindex($image, $rgb);
    
                    $red = ($colors['red'] & 0xFE) | intval($fileBits[$bitIndex++]);
                    $green = ($colors['green'] & 0xFE) | intval($fileBits[$bitIndex++]);
                    $blue = ($colors['blue'] & 0xFE) | intval($fileBits[$bitIndex++]);
    
                    $newColor = imagecolorallocate($image, $red, $green, $blue);
                    imagesetpixel($image, $x, $y, $newColor);
                }
            }
    
            imagepng($image, $outputImagePath);
            imagedestroy($image);
            echo "File berhasil disembunyikan dalam gambar.\n";
        }
    
        private function readFileFromImage($imagePath, $outputFilePath)
        {
            $image = imagecreatefrompng($imagePath);
            if (!$image) {
                die("Gagal membuka gambar.");
            }
    
            $width = imagesx($image);
            $height = imagesy($image);
    
            $fileBits = '';
            for ($y = 0; $y < $height; $y++) {
                for ($x = 0; $x < $width; $x++) {
                    $rgb = imagecolorat($image, $x, $y);
                    $colors = imagecolorsforindex($image, $rgb);
    
                    $fileBits .= ($colors['red'] & 1);
                    $fileBits .= ($colors['green'] & 1);
                    $fileBits .= ($colors['blue'] & 1);
                }
            }
    
            // Membaca panjang file dari bit awal
            $sizeBits = substr($fileBits, 0, 32);
            $fileSize = bindec($sizeBits);
    
            $fileContents = '';
            for ($i = 32; $i < 32 + $fileSize * 8; $i += 8) {
                $char = chr(bindec(substr($fileBits, $i, 8)));
                $fileContents .= $char;
            }
    
            file_put_contents($outputFilePath, $fileContents);
            imagedestroy($image);
            echo "File berhasil dibaca dari gambar.\n";
        }
}